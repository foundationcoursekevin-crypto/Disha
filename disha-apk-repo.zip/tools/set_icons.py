"""Puts the Disha compass icon into the generated Android project."""
from PIL import Image
import os

RES = "android/app/src/main/res"
icon = Image.open("www/icon-512.png").convert("RGBA")
fg = Image.open("www/icon-512-maskable.png").convert("RGBA")

for d, s in {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192}.items():
    p = f"{RES}/mipmap-{d}"
    os.makedirs(p, exist_ok=True)
    for n in ("ic_launcher.png", "ic_launcher_round.png"):
        icon.resize((s, s), Image.LANCZOS).save(f"{p}/{n}")

os.makedirs(f"{RES}/drawable-nodpi", exist_ok=True)
fg.resize((432, 432), Image.LANCZOS).save(f"{RES}/drawable-nodpi/disha_fg.png")

os.makedirs(f"{RES}/values", exist_ok=True)
with open(f"{RES}/values/disha_colors.xml", "w") as f:
    f.write('<?xml version="1.0" encoding="utf-8"?>\n<resources><color name="disha_bg">#14183F</color></resources>\n')

os.makedirs(f"{RES}/mipmap-anydpi-v26", exist_ok=True)
xml = ('<?xml version="1.0" encoding="utf-8"?>\n'
       '<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">'
       '<background android:drawable="@color/disha_bg"/>'
       '<foreground android:drawable="@drawable/disha_fg"/>'
       '</adaptive-icon>\n')
for n in ("ic_launcher.xml", "ic_launcher_round.xml"):
    with open(f"{RES}/mipmap-anydpi-v26/{n}", "w") as f:
        f.write(xml)
print("icons set")
